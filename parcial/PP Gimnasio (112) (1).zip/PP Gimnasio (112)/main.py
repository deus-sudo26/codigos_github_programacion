

def main():
    lista_opciones = [
        "Cargar socio",
        "Mostrar socios",
        "Buscar socio por ID",
        "Ordenar socios por Apellido",
        "Recaudacion por plan",
        "Calcular porcentaje por plan",
        "Salir"
    ]

    planes_activos = [
        "Musculacion",
        "Funcional",
        "Pileta",
        "Full"
    ]
    valores_planes_activos = [
        19000,
        15000,
        23000, 
        50000
    ]

    while True:
        pass


if __name__ == "__main__":
    main()