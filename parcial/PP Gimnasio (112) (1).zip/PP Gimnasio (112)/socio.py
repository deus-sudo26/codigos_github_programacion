def mostrar_un_socio(nombre, apellido, id_socio, edad, plan, cuota, asistencia):
    pass


def mostrar_socios(nombres, apellidos, ids_socios, edades, planes, cuotas, asistencias):
    pass


def cargar_socio(nombres, apellidos, ids_socios, edades, planes, cuotas, asistencias):
    pass


def buscar_socio(id_buscado, nombres, apellidos, ids_socios, edades, planes, cuotas, asistencias):
    pass


def ordenar_por_apellido(ids_socios, nombres, apellidos, edades, planes, cuotas, asistencias):
    pass


def calcular_recaudacion_por_plan(planes_socios, cuotas_socios, planes_activos):
    pass


def calcular_porcentaje_por_plan(planes_socios, cuotas_socios, planes_activos):
    pass